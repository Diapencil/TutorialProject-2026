using System;
using System.Collections.Generic;
using System.IO;
using SheepSheepBurger.BurgerAssembly;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace SheepSheepBurger.Economy.Editor
{
    public static class EconomySystemVerifier
    {
        private const string SceneDirectory = "Assets/@Developers/ChoiHJ/Economy/Scenes";
        private const string ScenePath = SceneDirectory + "/ShopPrototype.unity";

        [MenuItem("Sheep Sheep Burger/Verify Economy System")]
        public static void VerifyOnly()
        {
            VerifyModel();
            Debug.Log("[Economy] Economy and shop verification completed successfully.");
        }

        [MenuItem("Sheep Sheep Burger/Build Shop Prototype Scene")]
        public static void BuildShopPrototypeScene()
        {
            if (!Application.isBatchMode && !EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo())
            {
                return;
            }

            SceneSetup[] originalSetup = EditorSceneManager.GetSceneManagerSetup();
            try
            {
                VerifyModel();
                BuildScene();
                Debug.Log("[Economy] Shop prototype scene build completed successfully.");
            }
            finally
            {
                if (originalSetup.Length > 0)
                {
                    EditorSceneManager.RestoreSceneManagerSetup(originalSetup);
                }
            }
        }

        private static void VerifyModel()
        {
            ShopCatalog catalog = ShopCatalog.CreateDefault();
            var economy = new EconomyService(catalog);
            PlayerEconomyState state = PlayerEconomyState.CreateNewGame();

            Require(EconomyRules.StartingDebt == 1500, "Starting debt must be 1500S.");
            Require(EconomyRules.DebtDeadlineDays == 30, "Debt deadline must be 30 days.");
            Require(EconomyRules.CustomersPerDay == 8, "A day must serve eight customers.");

            RecipeData recipe = RecipeData.CreateBasicBurger();
            OrderEvaluation excellent = economy.EvaluateBurger(recipe, CreateBurger(
                IngredientType.BunBottom,
                IngredientType.Patty,
                IngredientType.BunTop));
            Require(excellent.satisfaction == CustomerSatisfaction.Excellent, "Exact recipe must be Excellent.");
            Require(excellent.totalPayment == 10 && excellent.tip == 5, "Excellent must pay 5 base plus 5 tip.");

            OrderEvaluation good = economy.EvaluateBurger(recipe, CreateBurger(
                IngredientType.BunBottom,
                IngredientType.Patty));
            Require(good.satisfaction == CustomerSatisfaction.Good, "One missing ingredient must be Good.");
            Require(good.totalPayment == 8 && good.tip == 3, "Good must pay 5 base plus 3 tip.");

            OrderEvaluation normal = economy.EvaluateBurger(recipe, CreateBurger(
                IngredientType.BunBottom));
            Require(normal.satisfaction == CustomerSatisfaction.Normal, "Two mismatches must be Normal.");
            Require(normal.totalPayment == 5 && normal.tip == 0, "Normal must pay base price only.");

            OrderEvaluation terrible = economy.EvaluateBurger(recipe, CreateBurger(
                IngredientType.ToppingBacon,
                IngredientType.ToppingFriedEgg,
                IngredientType.ToppingJalapeno));
            Require(terrible.satisfaction == CustomerSatisfaction.Terrible, "Three or more mismatches must be Terrible.");
            Require(terrible.totalPayment == 0 && !terrible.customerPays, "Terrible customers must not pay.");

            for (int index = 0; index < EconomyRules.CustomersPerDay; index++)
            {
                Require(economy.TryRecordServedOrder(state, excellent), "The first eight customers must be accepted.");
            }
            Require(!economy.TryRecordServedOrder(state, excellent), "A ninth same-day customer must be rejected.");
            Require(state.money == 80, "Eight excellent orders should earn 80S before material costs.");

            state.money = EconomyRules.DefaultShopItemPrice;
            ShopPurchaseResult purchase = economy.TryBuyItem(state, ShopItemId.Bacon);
            Require(purchase.success && state.HasPurchased(ShopItemId.Bacon), "Bacon should be purchasable and unlocked at 500S.");
            Require(catalog.GetUnlockedIngredients(state).Contains(IngredientType.ToppingBacon), "Purchased bacon must unlock unlimited bacon use.");

            state.money = 100;
            RepairDamageEvent damage = economy.RecordRepairDamage(state, RepairDamageSeverity.Moderate, "Customer broke a counter plate.");
            Require(damage.cost == EconomyRules.ModerateRepairCost, "Moderate damage must create the configured repair cost.");
            Require(state.repairCostToday == EconomyRules.ModerateRepairCost, "Repair damage must accumulate on the current day.");
            DaySettlement settlement = economy.CloseDay(state);
            Require(settlement.materialCost == EconomyRules.BaseDailyMaterialCost + EconomyRules.DefaultUnlockedIngredientDailyFee, "Daily material cost must include purchased ingredient upkeep.");
            Require(settlement.repairCost == EconomyRules.ModerateRepairCost, "Day settlement must charge accumulated repair costs.");
            Require(settlement.moneyAfterSettlement == 100 - settlement.materialCost - settlement.repairCost, "Money after settlement must subtract material and repair costs.");
            Require(state.dayClosed, "Closing the day must lock the day until BeginNextDay.");

            state.BeginNextDay();
            Require(state.repairCostToday == 0 && state.repairIncidentsToday == 0, "Repair counters must reset on the next day.");

            PlayerEconomyState deadlineState = PlayerEconomyState.CreateNewGame(1700);
            deadlineState.dayNumber = EconomyRules.DebtDeadlineDays;
            DaySettlement deadline = economy.CloseDay(deadlineState);
            Require(deadline.debtPaid == EconomyRules.StartingDebt, "Deadline close should auto-pay debt when enough money is available.");
            Require(deadline.debtStatus == DebtStatus.Cleared, "Paid debt must be cleared.");
        }

        private static BurgerData CreateBurger(params IngredientType[] ingredients)
        {
            var placements = new List<IngredientPlacement>();
            for (int index = 0; index < ingredients.Length; index++)
            {
                placements.Add(new IngredientPlacement(ingredients[index], Vector2.zero, index));
            }

            return new BurgerData(placements);
        }

        private static void BuildScene()
        {
            Directory.CreateDirectory(SceneDirectory);
            Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            scene.name = "ShopPrototype";

            var cameraObject = new GameObject("Main Camera", typeof(Camera), typeof(AudioListener));
            cameraObject.tag = "MainCamera";
            Camera camera = cameraObject.GetComponent<Camera>();
            camera.clearFlags = CameraClearFlags.SolidColor;
            camera.backgroundColor = new Color(0.71f, 0.85f, 0.65f);
            camera.orthographic = true;
            cameraObject.transform.position = new Vector3(0f, 0f, -10f);

            var shopObject = new GameObject("ShopScreen", typeof(ShopScreenController));
            shopObject.transform.position = Vector3.zero;

            EditorSceneManager.MarkSceneDirty(scene);
            if (!EditorSceneManager.SaveScene(scene, ScenePath))
            {
                throw new InvalidOperationException("Failed to save " + ScenePath);
            }

            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
        }

        private static void Require(bool condition, string message)
        {
            if (!condition)
            {
                throw new InvalidOperationException("[Economy verification] " + message);
            }
        }
    }
}
