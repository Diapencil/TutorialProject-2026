using System;
using System.Collections.Generic;
using SheepSheepBurger.BurgerAssembly;

namespace SheepSheepBurger.Economy
{
    public sealed class ShopCatalog
    {
        private readonly List<ShopItemData> items;

        public ShopCatalog(IEnumerable<ShopItemData> source)
        {
            if (source == null)
            {
                throw new ArgumentNullException(nameof(source));
            }

            items = new List<ShopItemData>(source);
        }

        public IList<ShopItemData> Items => items.AsReadOnly();

        public static ShopCatalog CreateDefault()
        {
            return new ShopCatalog(new[]
            {
                new ShopItemData(
                    ShopItemId.Bacon,
                    ShopCategory.Topping,
                    "베이컨",
                    "돼지야 미안!",
                    EconomyRules.DefaultShopItemPrice,
                    EconomyRules.DefaultUnlockedIngredientDailyFee,
                    IngredientType.ToppingBacon),
                new ShopItemData(
                    ShopItemId.FriedEgg,
                    ShopCategory.Topping,
                    "계란후라이",
                    "닭아 미안!",
                    EconomyRules.DefaultShopItemPrice,
                    EconomyRules.DefaultUnlockedIngredientDailyFee,
                    IngredientType.ToppingFriedEgg),
                new ShopItemData(
                    ShopItemId.Pickle,
                    ShopCategory.Topping,
                    "피클",
                    "피클은 안 미안!",
                    EconomyRules.DefaultShopItemPrice,
                    EconomyRules.DefaultUnlockedIngredientDailyFee,
                    IngredientType.ToppingPickle),
                new ShopItemData(
                    ShopItemId.Jalapeno,
                    ShopCategory.Topping,
                    "할라피뇨",
                    "할라피뇨도 안 미안!",
                    EconomyRules.DefaultShopItemPrice,
                    EconomyRules.DefaultUnlockedIngredientDailyFee,
                    IngredientType.ToppingJalapeno)
            });
        }

        public bool TryGetItem(ShopItemId itemId, out ShopItemData item)
        {
            for (int index = 0; index < items.Count; index++)
            {
                if (items[index].id == itemId)
                {
                    item = items[index];
                    return true;
                }
            }

            item = null;
            return false;
        }

        public List<ShopItemData> GetItems(ShopCategory category)
        {
            var result = new List<ShopItemData>();
            for (int index = 0; index < items.Count; index++)
            {
                if (items[index].category == category)
                {
                    result.Add(items[index]);
                }
            }

            return result;
        }

        public int GetDailyIngredientFee(PlayerEconomyState state)
        {
            if (state == null)
            {
                throw new ArgumentNullException(nameof(state));
            }

            int total = 0;
            for (int index = 0; index < items.Count; index++)
            {
                ShopItemData item = items[index];
                if (item.unlocksIngredient && state.HasPurchased(item.id))
                {
                    total += item.dailyIngredientFee;
                }
            }

            return total;
        }

        public List<IngredientType> GetUnlockedIngredients(PlayerEconomyState state)
        {
            if (state == null)
            {
                throw new ArgumentNullException(nameof(state));
            }

            var unlocked = new List<IngredientType>
            {
                IngredientType.BunBottom,
                IngredientType.BunTop,
                IngredientType.Patty,
                IngredientType.ToppingLettuce,
                IngredientType.ToppingTomato,
                IngredientType.ToppingCheese,
                IngredientType.ToppingOnion,
                IngredientType.SauceKetchup,
                IngredientType.SauceMustard
            };

            for (int index = 0; index < items.Count; index++)
            {
                ShopItemData item = items[index];
                if (item.unlocksIngredient && state.HasPurchased(item.id) && !unlocked.Contains(item.ingredientType))
                {
                    unlocked.Add(item.ingredientType);
                }
            }

            return unlocked;
        }
    }
}
