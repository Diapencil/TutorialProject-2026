# SheepSheep Burger Economy and Shop

This module implements the first economy pass from the shop/economy notes.

## Confirmed rules

- Debt: 1500S due by day 30.
- Customers per day: 8.
- Basic burger price: 5S.
- Satisfaction payout:
  - Excellent, exact recipe: 5S base + 5S tip.
  - Good, one mismatch: 5S base + 3S tip.
  - Normal, two mismatches: 5S base, no tip.
  - Terrible, three or more mismatches: customer does not pay.
- Material costs are charged when the day closes.
- Purchased ingredients are unlocked permanently and can be used without quantity limits.
- Repair costs are charged when the day closes. Customer damage can be recorded during the day, and the total repair cost is subtracted from money during settlement.

## Shop catalog

The current catalog follows `상점+설정창UI.pptx`:

- Bacon: 500S
- Fried egg: 500S
- Pickle: 500S
- Jalapeno: 500S

Each unlocked ingredient currently adds a small daily material upkeep fee through `ShopItemData.dailyIngredientFee`.
Change `EconomyRules.DefaultUnlockedIngredientDailyFee` or the per-item values in `ShopCatalog.CreateDefault()` when final balancing is decided.

## Integration points

- Use `EconomyService.EvaluateBurger(recipe, burgerData)` after `BurgerAssemblyController.OnBurgerCompleted`.
- Use `EconomyService.TryRecordServedOrder(state, evaluation)` after each served customer.
- Use `EconomyService.RecordRepairDamage(state, severity)` when a customer breaks something.
- Use `EconomyService.RollAndRecordCustomerDamage(state, random)` if the caller wants the default occasional damage roll.
- Use `EconomyService.CloseDay(state)` after the eighth customer or the day-end flow.
- Use `EconomyService.TryBuyItem(state, itemId)` from shop buttons.
- Use `PlayerPrefsEconomyStore` for a simple local save, or replace it with a project save system later.

## Editor verification

- `Sheep Sheep Burger > Verify Economy System` runs model assertions.
- `Sheep Sheep Burger > Build Shop Prototype Scene` creates `Assets/@Developers/ChoiHJ/Economy/Scenes/ShopPrototype.unity`.
