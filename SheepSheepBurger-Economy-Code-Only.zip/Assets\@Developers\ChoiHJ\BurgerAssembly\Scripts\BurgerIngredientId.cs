namespace SheepSheepBurger.BurgerAssembly
{
    public enum IngredientType
    {
        Patty,
        BunBottom,
        BunTop,
        ToppingLettuce,
        ToppingTomato,
        ToppingCheese,
        ToppingOnion,
        ToppingPickle,
        ToppingBacon,
        ToppingFriedEgg,
        ToppingJalapeno,
        SauceKetchup,
        SauceMustard
    }

    public enum CookingDragKind
    {
        Ingredient,
        RawPatty,
        CookedPatty,
        Sauce
    }

    public enum CookingCameraZone
    {
        Grill,
        Board
    }
}
