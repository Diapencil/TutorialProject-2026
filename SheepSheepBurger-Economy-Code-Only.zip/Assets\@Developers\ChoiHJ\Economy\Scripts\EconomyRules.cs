using System;

namespace SheepSheepBurger.Economy
{
    public static class EconomyRules
    {
        public const int DebtDeadlineDays = 30;
        public const int StartingDebt = 1500;
        public const int CustomersPerDay = 8;
        public const int BasicBurgerPrice = 5;
        public const int ExcellentTip = 5;
        public const int GoodTip = 3;
        public const int BaseDailyMaterialCost = 8;
        public const int DefaultShopItemPrice = 500;
        public const int DefaultUnlockedIngredientDailyFee = 2;
        public const int MinorRepairCost = 20;
        public const int ModerateRepairCost = 50;
        public const int MajorRepairCost = 100;
        public const int SevereRepairCost = 200;
        public const int DefaultCustomerDamageChancePercent = 10;

        public static CustomerSatisfaction GetSatisfaction(int mismatchCount)
        {
            if (mismatchCount < 0)
            {
                throw new ArgumentOutOfRangeException(nameof(mismatchCount));
            }

            if (mismatchCount == 0)
            {
                return CustomerSatisfaction.Excellent;
            }

            if (mismatchCount == 1)
            {
                return CustomerSatisfaction.Good;
            }

            if (mismatchCount == 2)
            {
                return CustomerSatisfaction.Normal;
            }

            return CustomerSatisfaction.Terrible;
        }

        public static OrderEvaluation CreatePayout(int mismatchCount)
        {
            CustomerSatisfaction satisfaction = GetSatisfaction(mismatchCount);
            int basePayment = satisfaction == CustomerSatisfaction.Terrible ? 0 : BasicBurgerPrice;
            int tip = 0;
            if (satisfaction == CustomerSatisfaction.Excellent)
            {
                tip = ExcellentTip;
            }
            else if (satisfaction == CustomerSatisfaction.Good)
            {
                tip = GoodTip;
            }

            return new OrderEvaluation
            {
                mismatchCount = mismatchCount,
                satisfaction = satisfaction,
                basePayment = basePayment,
                tip = tip,
                totalPayment = basePayment + tip,
                customerPays = satisfaction != CustomerSatisfaction.Terrible
            };
        }

        public static int GetRepairCost(RepairDamageSeverity severity)
        {
            switch (severity)
            {
                case RepairDamageSeverity.None:
                    return 0;
                case RepairDamageSeverity.Minor:
                    return MinorRepairCost;
                case RepairDamageSeverity.Moderate:
                    return ModerateRepairCost;
                case RepairDamageSeverity.Major:
                    return MajorRepairCost;
                case RepairDamageSeverity.Severe:
                    return SevereRepairCost;
                default:
                    throw new ArgumentOutOfRangeException(nameof(severity));
            }
        }

        public static string GetRepairDescription(RepairDamageSeverity severity)
        {
            switch (severity)
            {
                case RepairDamageSeverity.None:
                    return "No damage";
                case RepairDamageSeverity.Minor:
                    return "Small mess cleanup";
                case RepairDamageSeverity.Moderate:
                    return "Counter repair";
                case RepairDamageSeverity.Major:
                    return "Broken shop equipment";
                case RepairDamageSeverity.Severe:
                    return "Heavy shop damage";
                default:
                    throw new ArgumentOutOfRangeException(nameof(severity));
            }
        }

        public static DebtStatus GetDebtStatus(PlayerEconomyState state)
        {
            if (state == null)
            {
                throw new ArgumentNullException(nameof(state));
            }

            if (state.debtRemaining <= 0)
            {
                return DebtStatus.Cleared;
            }

            if (state.dayNumber > DebtDeadlineDays)
            {
                return DebtStatus.Failed;
            }

            return state.dayNumber == DebtDeadlineDays ? DebtStatus.DueToday : DebtStatus.InProgress;
        }
    }
}
