using System;
using System.Collections.Generic;
using SheepSheepBurger.BurgerAssembly;

namespace SheepSheepBurger.Economy
{
    public enum CustomerSatisfaction
    {
        Excellent,
        Good,
        Normal,
        Terrible
    }

    public enum DebtStatus
    {
        InProgress,
        DueToday,
        Cleared,
        Failed
    }

    public enum ShopCategory
    {
        Topping,
        Upgrade,
        Repair,
        Decoration
    }

    public enum ShopItemId
    {
        Bacon,
        FriedEgg,
        Pickle,
        Jalapeno
    }

    public enum RepairDamageSeverity
    {
        None,
        Minor,
        Moderate,
        Major,
        Severe
    }

    [Serializable]
    public sealed class RecipeData
    {
        public string recipeId;
        public List<IngredientType> requiredIngredients = new List<IngredientType>();

        public RecipeData()
        {
        }

        public RecipeData(string recipeId, IEnumerable<IngredientType> ingredients)
        {
            this.recipeId = recipeId;
            requiredIngredients = new List<IngredientType>(ingredients);
        }

        public static RecipeData CreateBasicBurger()
        {
            return new RecipeData(
                "basic_burger",
                new[]
                {
                    IngredientType.BunBottom,
                    IngredientType.Patty,
                    IngredientType.BunTop
                });
        }
    }

    [Serializable]
    public sealed class OrderEvaluation
    {
        public int mismatchCount;
        public CustomerSatisfaction satisfaction;
        public int basePayment;
        public int tip;
        public int totalPayment;
        public bool customerPays;
    }

    [Serializable]
    public sealed class DaySettlement
    {
        public int dayNumber;
        public int customersServed;
        public int revenueEarned;
        public int tipsEarned;
        public int unpaidCustomers;
        public int materialCost;
        public int repairCost;
        public int repairIncidents;
        public int debtPaid;
        public int moneyAfterSettlement;
        public int debtRemaining;
        public DebtStatus debtStatus;
        public bool canContinue;
    }

    [Serializable]
    public sealed class RepairDamageEvent
    {
        public RepairDamageSeverity severity;
        public int cost;
        public string description;

        public RepairDamageEvent()
        {
        }

        public RepairDamageEvent(RepairDamageSeverity severity, int cost, string description)
        {
            this.severity = severity;
            this.cost = cost;
            this.description = description;
        }
    }

    [Serializable]
    public sealed class ShopItemData
    {
        public ShopItemId id;
        public ShopCategory category;
        public string displayName;
        public string flavorText;
        public int price;
        public int dailyIngredientFee;
        public bool unlocksIngredient;
        public IngredientType ingredientType;

        public ShopItemData()
        {
        }

        public ShopItemData(
            ShopItemId id,
            ShopCategory category,
            string displayName,
            string flavorText,
            int price,
            int dailyIngredientFee,
            IngredientType ingredientType)
        {
            this.id = id;
            this.category = category;
            this.displayName = displayName;
            this.flavorText = flavorText;
            this.price = price;
            this.dailyIngredientFee = dailyIngredientFee;
            this.unlocksIngredient = true;
            this.ingredientType = ingredientType;
        }
    }

    [Serializable]
    public sealed class ShopPurchaseResult
    {
        public bool success;
        public string message;
        public ShopItemId itemId;
        public int moneyAfterPurchase;

        public static ShopPurchaseResult Succeeded(ShopItemData item, int moneyAfterPurchase)
        {
            return new ShopPurchaseResult
            {
                success = true,
                message = item.displayName + " 해금 완료",
                itemId = item.id,
                moneyAfterPurchase = moneyAfterPurchase
            };
        }

        public static ShopPurchaseResult Failed(ShopItemId itemId, string message, int moneyAfterPurchase)
        {
            return new ShopPurchaseResult
            {
                success = false,
                message = message,
                itemId = itemId,
                moneyAfterPurchase = moneyAfterPurchase
            };
        }
    }
}
