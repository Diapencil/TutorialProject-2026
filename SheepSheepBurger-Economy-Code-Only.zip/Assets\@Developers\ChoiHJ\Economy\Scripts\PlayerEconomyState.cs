using System;
using System.Collections.Generic;

namespace SheepSheepBurger.Economy
{
    [Serializable]
    public sealed class PlayerEconomyState
    {
        public int dayNumber = 1;
        public int money;
        public int debtRemaining = EconomyRules.StartingDebt;
        public int customersServedToday;
        public int revenueToday;
        public int tipsToday;
        public int unpaidCustomersToday;
        public int repairCostToday;
        public int repairIncidentsToday;
        public RepairDamageSeverity worstRepairDamageToday;
        public bool dayClosed;
        public List<ShopItemId> purchasedItems = new List<ShopItemId>();

        public static PlayerEconomyState CreateNewGame(int startingMoney = 0)
        {
            var state = new PlayerEconomyState
            {
                dayNumber = 1,
                money = startingMoney,
                debtRemaining = EconomyRules.StartingDebt
            };
            state.Sanitize();
            return state;
        }

        public void Sanitize()
        {
            if (dayNumber < 1)
            {
                dayNumber = 1;
            }

            if (debtRemaining < 0)
            {
                debtRemaining = 0;
            }

            if (purchasedItems == null)
            {
                purchasedItems = new List<ShopItemId>();
            }

            for (int index = purchasedItems.Count - 1; index >= 0; index--)
            {
                if (purchasedItems.IndexOf(purchasedItems[index]) != index)
                {
                    purchasedItems.RemoveAt(index);
                }
            }
        }

        public bool HasPurchased(ShopItemId itemId)
        {
            return purchasedItems != null && purchasedItems.Contains(itemId);
        }

        public void MarkPurchased(ShopItemId itemId)
        {
            if (purchasedItems == null)
            {
                purchasedItems = new List<ShopItemId>();
            }

            if (!purchasedItems.Contains(itemId))
            {
                purchasedItems.Add(itemId);
            }
        }

        public bool CanServeMoreCustomers()
        {
            return !dayClosed && customersServedToday < EconomyRules.CustomersPerDay;
        }

        public void BeginNextDay()
        {
            if (!dayClosed)
            {
                throw new InvalidOperationException("Cannot begin the next day before closing the current day.");
            }

            dayNumber++;
            customersServedToday = 0;
            revenueToday = 0;
            tipsToday = 0;
            unpaidCustomersToday = 0;
            repairCostToday = 0;
            repairIncidentsToday = 0;
            worstRepairDamageToday = RepairDamageSeverity.None;
            dayClosed = false;
        }
    }
}
