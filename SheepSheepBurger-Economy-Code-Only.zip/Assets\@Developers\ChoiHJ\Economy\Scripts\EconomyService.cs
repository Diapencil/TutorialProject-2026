using System;
using System.Collections.Generic;
using SheepSheepBurger.BurgerAssembly;

namespace SheepSheepBurger.Economy
{
    public sealed class EconomyService
    {
        private readonly ShopCatalog catalog;

        public EconomyService(ShopCatalog catalog = null)
        {
            this.catalog = catalog ?? ShopCatalog.CreateDefault();
        }

        public OrderEvaluation EvaluateBurger(RecipeData recipe, BurgerData burger)
        {
            if (recipe == null)
            {
                throw new ArgumentNullException(nameof(recipe));
            }

            int mismatchCount = CountIngredientMismatches(recipe.requiredIngredients, burger);
            return EconomyRules.CreatePayout(mismatchCount);
        }

        public bool TryRecordServedOrder(PlayerEconomyState state, OrderEvaluation evaluation)
        {
            if (state == null)
            {
                throw new ArgumentNullException(nameof(state));
            }

            if (evaluation == null)
            {
                throw new ArgumentNullException(nameof(evaluation));
            }

            state.Sanitize();
            if (!state.CanServeMoreCustomers())
            {
                return false;
            }

            state.customersServedToday++;
            state.money += evaluation.totalPayment;
            state.revenueToday += evaluation.totalPayment;
            state.tipsToday += evaluation.tip;
            if (!evaluation.customerPays)
            {
                state.unpaidCustomersToday++;
            }

            return true;
        }

        public RepairDamageEvent RecordRepairDamage(
            PlayerEconomyState state,
            RepairDamageSeverity severity,
            string description = null)
        {
            if (state == null)
            {
                throw new ArgumentNullException(nameof(state));
            }

            state.Sanitize();
            int cost = EconomyRules.GetRepairCost(severity);
            var damageEvent = new RepairDamageEvent(
                severity,
                cost,
                string.IsNullOrEmpty(description) ? EconomyRules.GetRepairDescription(severity) : description);

            if (severity == RepairDamageSeverity.None || cost <= 0)
            {
                return damageEvent;
            }

            state.repairCostToday += cost;
            state.repairIncidentsToday++;
            if (severity > state.worstRepairDamageToday)
            {
                state.worstRepairDamageToday = severity;
            }

            return damageEvent;
        }

        public RepairDamageEvent RollAndRecordCustomerDamage(
            PlayerEconomyState state,
            System.Random random,
            int chancePercent = EconomyRules.DefaultCustomerDamageChancePercent)
        {
            if (random == null)
            {
                throw new ArgumentNullException(nameof(random));
            }

            if (chancePercent < 0 || chancePercent > 100)
            {
                throw new ArgumentOutOfRangeException(nameof(chancePercent));
            }

            if (random.Next(0, 100) >= chancePercent)
            {
                return RecordRepairDamage(state, RepairDamageSeverity.None);
            }

            int roll = random.Next(0, 100);
            RepairDamageSeverity severity;
            if (roll < 55)
            {
                severity = RepairDamageSeverity.Minor;
            }
            else if (roll < 82)
            {
                severity = RepairDamageSeverity.Moderate;
            }
            else if (roll < 96)
            {
                severity = RepairDamageSeverity.Major;
            }
            else
            {
                severity = RepairDamageSeverity.Severe;
            }

            return RecordRepairDamage(state, severity);
        }

        public DaySettlement CloseDay(PlayerEconomyState state, bool payDebtAutomaticallyAtDeadline = true)
        {
            if (state == null)
            {
                throw new ArgumentNullException(nameof(state));
            }

            state.Sanitize();
            int materialCost = EconomyRules.BaseDailyMaterialCost + catalog.GetDailyIngredientFee(state);
            int repairCost = state.repairCostToday;
            state.money -= materialCost + repairCost;

            int debtPaid = 0;
            if (payDebtAutomaticallyAtDeadline &&
                state.dayNumber >= EconomyRules.DebtDeadlineDays &&
                state.debtRemaining > 0 &&
                state.money >= state.debtRemaining)
            {
                debtPaid = state.debtRemaining;
                state.money -= state.debtRemaining;
                state.debtRemaining = 0;
            }

            state.dayClosed = true;
            DebtStatus debtStatus = EconomyRules.GetDebtStatus(state);
            bool canContinue = debtStatus != DebtStatus.Failed;
            return new DaySettlement
            {
                dayNumber = state.dayNumber,
                customersServed = state.customersServedToday,
                revenueEarned = state.revenueToday,
                tipsEarned = state.tipsToday,
                unpaidCustomers = state.unpaidCustomersToday,
                materialCost = materialCost,
                repairCost = repairCost,
                repairIncidents = state.repairIncidentsToday,
                debtPaid = debtPaid,
                moneyAfterSettlement = state.money,
                debtRemaining = state.debtRemaining,
                debtStatus = debtStatus,
                canContinue = canContinue
            };
        }

        public bool TryPayDebt(PlayerEconomyState state, int amount, out int paid)
        {
            if (state == null)
            {
                throw new ArgumentNullException(nameof(state));
            }

            if (amount < 0)
            {
                throw new ArgumentOutOfRangeException(nameof(amount));
            }

            state.Sanitize();
            paid = Math.Min(amount, Math.Min(state.money, state.debtRemaining));
            if (paid <= 0)
            {
                return false;
            }

            state.money -= paid;
            state.debtRemaining -= paid;
            return true;
        }

        public ShopPurchaseResult TryBuyItem(PlayerEconomyState state, ShopItemId itemId)
        {
            if (state == null)
            {
                throw new ArgumentNullException(nameof(state));
            }

            state.Sanitize();
            if (!catalog.TryGetItem(itemId, out ShopItemData item))
            {
                return ShopPurchaseResult.Failed(itemId, "상점 상품을 찾을 수 없습니다.", state.money);
            }

            if (state.HasPurchased(itemId))
            {
                return ShopPurchaseResult.Failed(itemId, "이미 해금한 상품입니다.", state.money);
            }

            if (state.money < item.price)
            {
                return ShopPurchaseResult.Failed(itemId, "돈이 부족합니다.", state.money);
            }

            state.money -= item.price;
            state.MarkPurchased(itemId);
            return ShopPurchaseResult.Succeeded(item, state.money);
        }

        public int CountIngredientMismatches(IEnumerable<IngredientType> requiredIngredients, BurgerData burger)
        {
            Dictionary<IngredientType, int> required = BuildCounts(requiredIngredients);
            Dictionary<IngredientType, int> served = BuildCounts(burger);
            int mismatches = 0;

            foreach (KeyValuePair<IngredientType, int> pair in required)
            {
                served.TryGetValue(pair.Key, out int servedCount);
                mismatches += Math.Abs(pair.Value - servedCount);
            }

            foreach (KeyValuePair<IngredientType, int> pair in served)
            {
                if (!required.ContainsKey(pair.Key))
                {
                    mismatches += pair.Value;
                }
            }

            return mismatches;
        }

        private static Dictionary<IngredientType, int> BuildCounts(IEnumerable<IngredientType> ingredients)
        {
            var counts = new Dictionary<IngredientType, int>();
            if (ingredients == null)
            {
                return counts;
            }

            foreach (IngredientType ingredient in ingredients)
            {
                AddCount(counts, NormalizeIngredient(ingredient));
            }

            return counts;
        }

        private static Dictionary<IngredientType, int> BuildCounts(BurgerData burger)
        {
            var counts = new Dictionary<IngredientType, int>();
            if (burger == null || burger.ingredients == null)
            {
                return counts;
            }

            var sauceTypesAlreadyCounted = new HashSet<IngredientType>();
            for (int index = 0; index < burger.ingredients.Count; index++)
            {
                IngredientPlacement placement = burger.ingredients[index];
                if (placement == null)
                {
                    continue;
                }

                IngredientType normalized = NormalizeIngredient(placement.type);
                if (IsSauce(normalized))
                {
                    if (sauceTypesAlreadyCounted.Contains(normalized))
                    {
                        continue;
                    }

                    sauceTypesAlreadyCounted.Add(normalized);
                }

                AddCount(counts, normalized);
            }

            return counts;
        }

        private static void AddCount(Dictionary<IngredientType, int> counts, IngredientType ingredient)
        {
            counts.TryGetValue(ingredient, out int current);
            counts[ingredient] = current + 1;
        }

        private static IngredientType NormalizeIngredient(IngredientType ingredient)
        {
            return ingredient;
        }

        private static bool IsSauce(IngredientType ingredient)
        {
            return ingredient == IngredientType.SauceKetchup || ingredient == IngredientType.SauceMustard;
        }
    }
}
