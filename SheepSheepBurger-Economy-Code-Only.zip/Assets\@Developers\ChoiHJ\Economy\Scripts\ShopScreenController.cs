using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem.UI;
using UnityEngine.UI;

namespace SheepSheepBurger.Economy
{
    [DisallowMultipleComponent]
    public sealed class ShopScreenController : MonoBehaviour
    {
        private const float ReferenceWidth = 1600f;
        private const float ReferenceHeight = 900f;

        private readonly Dictionary<ShopCategory, Button> categoryButtons = new Dictionary<ShopCategory, Button>();
        private readonly List<GameObject> itemCards = new List<GameObject>();

        [SerializeField] private bool loadFromPlayerPrefs = true;
        [SerializeField] private int debugStartingMoney = 0;
        [SerializeField] private ShopCategory selectedCategory = ShopCategory.Topping;

        private ShopCatalog catalog;
        private EconomyService economy;
        private PlayerEconomyState state;
        private RectTransform canvasRoot;
        private RectTransform cardRoot;
        private Text moneyText;
        private Text statusText;
        private Font uiFont;

        public PlayerEconomyState State => state;

        private void Awake()
        {
            catalog = ShopCatalog.CreateDefault();
            economy = new EconomyService(catalog);
            state = loadFromPlayerPrefs
                ? PlayerPrefsEconomyStore.LoadOrDefault()
                : PlayerEconomyState.CreateNewGame(debugStartingMoney);

            BuildInterface();
            Refresh();
        }

        public void SelectCategory(ShopCategory category)
        {
            selectedCategory = category;
            Refresh();
        }

        public void GiveDebugMoney(int amount)
        {
            if (amount <= 0)
            {
                return;
            }

            state.money += amount;
            Save();
            Refresh();
        }

        private void TryBuy(ShopItemId itemId)
        {
            ShopPurchaseResult result = economy.TryBuyItem(state, itemId);
            statusText.text = result.message;
            Save();
            Refresh();
        }

        private void RecordRepairDamage(RepairDamageSeverity severity)
        {
            RepairDamageEvent damageEvent = economy.RecordRepairDamage(state, severity);
            statusText.text = damageEvent.description + " +" + damageEvent.cost + "S";
            Save();
            Refresh();
        }

        private void Save()
        {
            if (loadFromPlayerPrefs)
            {
                PlayerPrefsEconomyStore.Save(state);
            }
        }

        private void BuildInterface()
        {
            uiFont = Font.CreateDynamicFontFromOSFont(new[] { "Malgun Gothic", "Arial" }, 28);
            if (uiFont == null)
            {
                uiFont = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            }

            GameObject canvasObject = new GameObject("ShopCanvas", typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
            canvasObject.transform.SetParent(transform, false);
            Canvas canvas = canvasObject.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;

            CanvasScaler scaler = canvasObject.GetComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(ReferenceWidth, ReferenceHeight);
            scaler.matchWidthOrHeight = 0.5f;

            canvasRoot = canvasObject.GetComponent<RectTransform>();
            SetStretch(canvasRoot);

            RectTransform background = CreateImage("ShopBackground", canvasRoot, Hex("#B4D8A6"), Vector2.zero, new Vector2(ReferenceWidth, ReferenceHeight), false);
            SetStretch(background);
            CreateImage("ShopPanel", canvasRoot, Hex("#42D459"), new Vector2(135f, -20f), new Vector2(1430f, 620f), false);
            CreateImage("ShopPanelBorder", canvasRoot, new Color(0.05f, 0.45f, 0.15f, 0.25f), new Vector2(135f, -20f), new Vector2(1438f, 628f), false).SetAsFirstSibling();

            RectTransform sidePanel = CreateImage("CategoryPanel", canvasRoot, Hex("#DDF4D5"), new Vector2(-665f, -20f), new Vector2(280f, 640f), false);
            BuildCategoryButton(sidePanel, ShopCategory.Topping, "토핑", new Vector2(0f, 190f));
            BuildCategoryButton(sidePanel, ShopCategory.Upgrade, "업그레이드", new Vector2(0f, 70f));
            BuildCategoryButton(sidePanel, ShopCategory.Repair, "수리", new Vector2(0f, -50f));
            BuildCategoryButton(sidePanel, ShopCategory.Decoration, "장식", new Vector2(0f, -170f));

            moneyText = CreateText("MoneyText", canvasRoot, string.Empty, 28, FontStyle.Bold, Hex("#1F3B22"), new Vector2(330f, 350f), new Vector2(840f, 48f));
            statusText = CreateText("ShopStatus", canvasRoot, string.Empty, 24, FontStyle.Bold, Hex("#1F3B22"), new Vector2(330f, -360f), new Vector2(920f, 48f));

            GameObject cardRootObject = new GameObject("ShopCardRoot", typeof(RectTransform));
            cardRoot = cardRootObject.GetComponent<RectTransform>();
            cardRoot.SetParent(canvasRoot, false);
            SetRect(cardRoot, new Vector2(135f, -20f), new Vector2(1260f, 560f));

            CreateEventSystem();
        }

        private void BuildCategoryButton(RectTransform parent, ShopCategory category, string label, Vector2 position)
        {
            RectTransform rect = CreateImage(category + "Button", parent, Hex("#81DB8F"), position, new Vector2(220f, 80f), true);
            Button button = rect.gameObject.AddComponent<Button>();
            button.targetGraphic = rect.GetComponent<Image>();
            ShopCategory targetCategory = category;
            button.onClick.AddListener(() => SelectCategory(targetCategory));
            CreateText(category + "Label", rect, label, 26, FontStyle.Bold, Hex("#173820"), Vector2.zero, rect.sizeDelta);
            categoryButtons[category] = button;
        }

        private void Refresh()
        {
            state.Sanitize();
            moneyText.text = $"보유 {state.money}S   빚 {state.debtRemaining}/{EconomyRules.StartingDebt}S   {state.dayNumber}일차";
            if (string.IsNullOrEmpty(statusText.text))
            {
                statusText.text = "해금한 재료는 수량 제한 없이 사용할 수 있습니다.";
            }

            foreach (KeyValuePair<ShopCategory, Button> pair in categoryButtons)
            {
                Image image = pair.Value.GetComponent<Image>();
                image.color = pair.Key == selectedCategory ? Hex("#BFF0C5") : Hex("#81DB8F");
            }

            RebuildCards();
        }

        private void RebuildCards()
        {
            for (int index = 0; index < itemCards.Count; index++)
            {
                Destroy(itemCards[index]);
            }
            itemCards.Clear();

            if (selectedCategory == ShopCategory.Repair)
            {
                CreateRepairPanel();
                return;
            }

            List<ShopItemData> items = catalog.GetItems(selectedCategory);
            if (items.Count == 0)
            {
                Text empty = CreateText("EmptyCategory", cardRoot, "준비 중", 34, FontStyle.Bold, Hex("#1F3B22"), Vector2.zero, new Vector2(500f, 80f));
                itemCards.Add(empty.gameObject);
                return;
            }

            float startX = -470f;
            for (int index = 0; index < items.Count; index++)
            {
                CreateItemCard(items[index], new Vector2(startX + index * 315f, 0f));
            }
        }

        private void CreateRepairPanel()
        {
            RectTransform panel = CreateImage("RepairPanel", cardRoot, Color.white, Vector2.zero, new Vector2(820f, 430f), false);
            itemCards.Add(panel.gameObject);
            CreateText("RepairTitle", panel, "오늘 수리비", 36, FontStyle.Bold, Color.black, new Vector2(0f, 155f), new Vector2(760f, 60f));
            CreateText(
                "RepairSummary",
                panel,
                state.repairIncidentsToday + "건 / " + state.repairCostToday + "S\n하루가 끝날 때 재료비와 함께 차감됩니다.",
                28,
                FontStyle.Bold,
                Color.black,
                new Vector2(0f, 65f),
                new Vector2(760f, 105f));

            CreateRepairButton(panel, RepairDamageSeverity.Minor, new Vector2(-300f, -105f));
            CreateRepairButton(panel, RepairDamageSeverity.Moderate, new Vector2(-100f, -105f));
            CreateRepairButton(panel, RepairDamageSeverity.Major, new Vector2(100f, -105f));
            CreateRepairButton(panel, RepairDamageSeverity.Severe, new Vector2(300f, -105f));
        }

        private void CreateRepairButton(RectTransform parent, RepairDamageSeverity severity, Vector2 position)
        {
            int cost = EconomyRules.GetRepairCost(severity);
            RectTransform rect = CreateImage(severity + "RepairButton", parent, Hex("#C7F1CE"), position, new Vector2(170f, 82f), true);
            Button button = rect.gameObject.AddComponent<Button>();
            button.targetGraphic = rect.GetComponent<Image>();
            RepairDamageSeverity targetSeverity = severity;
            button.onClick.AddListener(() => RecordRepairDamage(targetSeverity));
            CreateText(severity + "RepairLabel", rect, GetRepairLabel(severity) + "\n" + cost + "S", 20, FontStyle.Bold, Color.black, Vector2.zero, rect.sizeDelta);
        }

        private void CreateItemCard(ShopItemData item, Vector2 position)
        {
            RectTransform card = CreateImage(item.id + "Card", cardRoot, Color.white, position, new Vector2(280f, 510f), false);
            itemCards.Add(card.gameObject);
            CreateImage(item.id + "ArtFrame", card, Hex("#F7FFF4"), new Vector2(0f, 120f), new Vector2(230f, 170f), false);
            CreateText(item.id + "ArtLabel", card, GetArtLabel(item.id), 52, FontStyle.Bold, GetItemColor(item.id), new Vector2(0f, 120f), new Vector2(220f, 150f));
            CreateImage(item.id + "NameBar", card, Hex("#DDF4D5"), new Vector2(0f, 15f), new Vector2(292f, 62f), false);
            CreateText(item.id + "Name", card, item.displayName, 28, FontStyle.Bold, Color.black, new Vector2(0f, 15f), new Vector2(270f, 58f));
            CreateText(item.id + "Flavor", card, item.flavorText, 24, FontStyle.Normal, Color.black, new Vector2(0f, -90f), new Vector2(230f, 95f));

            bool purchased = state.HasPurchased(item.id);
            bool canAfford = state.money >= item.price;
            string buttonText = purchased ? "해금됨" : item.price + "S";
            Color buttonColor = purchased ? Hex("#C9D2CA") : (canAfford ? Hex("#C7F1CE") : Hex("#E5E5E5"));
            RectTransform buyRect = CreateImage(item.id + "Buy", card, buttonColor, new Vector2(0f, -190f), new Vector2(205f, 74f), true);
            Button buyButton = buyRect.gameObject.AddComponent<Button>();
            buyButton.targetGraphic = buyRect.GetComponent<Image>();
            buyButton.interactable = !purchased && canAfford;
            ShopItemId targetItem = item.id;
            buyButton.onClick.AddListener(() => TryBuy(targetItem));
            CreateText(item.id + "BuyLabel", buyRect, buttonText, 28, FontStyle.Bold, Color.black, Vector2.zero, buyRect.sizeDelta);
        }

        private static string GetArtLabel(ShopItemId itemId)
        {
            switch (itemId)
            {
                case ShopItemId.Bacon: return "~";
                case ShopItemId.FriedEgg: return "O";
                case ShopItemId.Pickle: return "ooo";
                case ShopItemId.Jalapeno: return "ooo";
                default: return "?";
            }
        }

        private static Color GetItemColor(ShopItemId itemId)
        {
            switch (itemId)
            {
                case ShopItemId.Bacon: return Hex("#E6A0A0");
                case ShopItemId.FriedEgg: return Hex("#F5BE31");
                case ShopItemId.Pickle: return Hex("#8DA96B");
                case ShopItemId.Jalapeno: return Hex("#75A75A");
                default: return Color.white;
            }
        }

        private static string GetRepairLabel(RepairDamageSeverity severity)
        {
            switch (severity)
            {
                case RepairDamageSeverity.Minor: return "약한 파손";
                case RepairDamageSeverity.Moderate: return "보통 파손";
                case RepairDamageSeverity.Major: return "큰 파손";
                case RepairDamageSeverity.Severe: return "심한 파손";
                default: return severity.ToString();
            }
        }

        private RectTransform CreateImage(string name, RectTransform parent, Color color, Vector2 position, Vector2 size, bool raycastTarget)
        {
            GameObject gameObject = new GameObject(name, typeof(RectTransform), typeof(Image));
            RectTransform rect = gameObject.GetComponent<RectTransform>();
            rect.SetParent(parent, false);
            SetRect(rect, position, size);
            Image image = gameObject.GetComponent<Image>();
            image.color = color;
            image.raycastTarget = raycastTarget;
            return rect;
        }

        private Text CreateText(string name, RectTransform parent, string value, int size, FontStyle style, Color color, Vector2 position, Vector2 dimensions)
        {
            GameObject gameObject = new GameObject(name, typeof(RectTransform), typeof(Text));
            RectTransform rect = gameObject.GetComponent<RectTransform>();
            rect.SetParent(parent, false);
            SetRect(rect, position, dimensions);
            Text text = gameObject.GetComponent<Text>();
            text.font = uiFont;
            text.fontSize = size;
            text.fontStyle = style;
            text.color = color;
            text.text = value;
            text.alignment = TextAnchor.MiddleCenter;
            text.horizontalOverflow = HorizontalWrapMode.Wrap;
            text.verticalOverflow = VerticalWrapMode.Overflow;
            text.raycastTarget = false;
            return text;
        }

        private static void SetRect(RectTransform rect, Vector2 position, Vector2 size)
        {
            rect.anchorMin = new Vector2(0.5f, 0.5f);
            rect.anchorMax = new Vector2(0.5f, 0.5f);
            rect.pivot = new Vector2(0.5f, 0.5f);
            rect.anchoredPosition = position;
            rect.sizeDelta = size;
        }

        private static void SetStretch(RectTransform rect)
        {
            rect.anchorMin = Vector2.zero;
            rect.anchorMax = Vector2.one;
            rect.pivot = new Vector2(0.5f, 0.5f);
            rect.offsetMin = Vector2.zero;
            rect.offsetMax = Vector2.zero;
        }

        private static Color Hex(string value)
        {
            return ColorUtility.TryParseHtmlString(value, out Color color) ? color : Color.magenta;
        }

        private static void CreateEventSystem()
        {
            EventSystem existing = FindFirstObjectByType<EventSystem>();
            if (existing != null)
            {
                return;
            }

            var eventSystemObject = new GameObject("EventSystem", typeof(EventSystem), typeof(InputSystemUIInputModule));
            eventSystemObject.GetComponent<InputSystemUIInputModule>().AssignDefaultActions();
        }
    }
}
